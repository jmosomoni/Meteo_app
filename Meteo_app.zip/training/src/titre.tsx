export default function Compo() {
return (

<h1>ma super appli</h1>

);}


