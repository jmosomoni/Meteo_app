// ============================================================
//  App.tsx — Composant principal de l'application météo
//  Affiche la météo d'une ville (température, humidité, vent)
//  à partir de l'API WeatherAPI.
// ============================================================

// --- Imports ---
// NB : plusieurs imports ci-dessous ne sont pas utilisés dans ce fichier
// (Compo, les éléments de './lo', useEffect, react-router, Accueil).
// Tu peux les supprimer pour nettoyer le code.
import Compo from './titre';
import IconeMeteo from './carte';                 // composant qui affiche l'icône météo
import { Po, Compteur, Night, Appel, Tache } from './lo';
import { useState, useEffect } from 'react';      // hooks React (on utilise useState)
import { BrowserRouter, Routes, Route, Link } from "react-router";
import { Accueil } from "./pages/accueil";


function App() {

  // --- Type des données météo renvoyées par l'API ---
  // On décrit la "forme" de l'objet pour que TypeScript nous aide.
  type Meteo = {
    location: { name: string };       // nom de la ville
    current: {
      temp_c: number;                 // température en °C
      is_day: number;                 // 1 = jour, 0 = nuit
      humidity: number;               // humidité en %
      wind_kph: number;               // vent en km/h
      condition: { text: string; code: number }; // description + code météo
    };
  };

  // --- Fonction qui va chercher la météo d'une ville ---
  async function testMeteo(ville: string) {
    if (ville.trim() === "") return;  // si le champ est vide, on ne fait rien

    try {
      // Appel à l'API WeatherAPI.
      // ⚠️ SÉCURITÉ : la clé API ne devrait PAS être écrite en dur ici
      // (visible par tous sur GitHub). À mettre dans un fichier .env :
      //   const cle = import.meta.env.VITE_WEATHER_API_KEY;
      //   ...?key=${cle}...
      const res = await fetch(
        `https://api.weatherapi.com/v1/current.json?key=4ed23fd1b8cb4222894131839262611&q=${encodeURIComponent(ville)}&lang=fr`
      );
      const data = await res.json();  // on transforme la réponse en objet JS

      // Si l'API renvoie une erreur (ville inconnue par ex.)
      if (data.error) {
        setMeteo(null);
        setErreur("Ville introuvable, Fais un effort bon sang de bonsoir");
        return;
      }

      // Sinon : pas d'erreur, on enregistre les données
      setErreur("");
      setMeteo(data);
    } catch {
      // Erreur réseau (pas de connexion, API injoignable...)
      setMeteo(null);
      setErreur("Problème de connexion");
    }
  }

  // --- États (mémoire du composant) ---
  const [meteo, setMeteo] = useState<Meteo | null>(null);  // les données météo (ou null)
  const [champ, setChamp] = useState("");                  // le texte tapé dans l'input
  const [erreur, setErreur] = useState("");                // le message d'erreur à afficher

  // --- Rendu (ce qui s'affiche à l'écran) ---
  return (
    // Conteneur plein écran, centré
    <div className='flex justify-center items-center h-screen'>

      {/* La "carte" météo : dégradé violet -> bleu, coins arrondis */}
      <div className='relative w-2/6 h-162 rounded-xl bg-linear-to-b from-purple-300 to-blue-800 bg-cover bg-no-repeat flex flex-col'>

        {/* Léger voile noir par-dessus le fond */}
        <div className="absolute inset-0 bg-black/5"></div>

        {/* --- Barre de recherche (input + bouton) --- */}
        <div className="relative z-10 flex h-30 flex justify-center gap-8">

          {/* Champ de saisie de la ville.
              - value/onChange : lie l'input à l'état "champ"
              - onKeyDown : lance la recherche si on appuie sur Entrée */}
          <input
            className="bg-white focus:outline-none rounded-4xl w-3/6 h-15 mt-14 pl-10"
            value={champ}
            onKeyDown={(e) => { if (e.key === "Enter") testMeteo(champ); }}
            onChange={(e) => setChamp(e.target.value)}
            type="text"
            placeholder='Ex : Lyon'
          />

          {/* Bouton loupe : lance la recherche au clic */}
          <button
            onClick={() => testMeteo(champ)}
            className="bg-white font-bold px-4 h-15 w-15 rounded-full mt-14 flex justify-center items-center"
          >
            <img src="/lol.png" className='w-6 h-6' />
          </button>

        </div>

        {/* --- Zone principale : icône + température + ville --- */}
        <div className='relative z-10 flex justify-center items-center'>

          {/* Message d'erreur (affiché seulement si "erreur" n'est pas vide) */}
          {erreur && <p className="relative z-10 text-white text-center font-semibold text-3xl mt-50">{erreur}</p>}

          {/* Bloc météo (affiché seulement si "meteo" existe) */}
          {meteo && (
            <div className="flex flex-col items-center text-white">
              {/* Icône dynamique selon le code météo et jour/nuit */}
              <IconeMeteo className="w-60 h-60" code={meteo.current.condition.code} isDay={meteo.current.is_day} />
              <h1 className='text-5xl uppercase'>{meteo.current.temp_c} °C</h1>
              <h1 className='text-4xl uppercase mt-5'>{meteo.location.name}</h1>
            </div>
          )}

        </div>

        {/* --- Bas de carte : humidité + vent (si météo chargée) --- */}
        {meteo && (
          <div className="flex items-center justify-start gap-5 mt-2">

            {/* Bloc humidité (relative -left-4 = décalé un peu à gauche) */}
            <div className='flex items-center pr-9 relative -left-4'>
              <img src="/meteo/humidite.svg" alt="Humidité" className="w-40 h-40 -mr-8" />
              <div className='flex flex-col gap-2'>
                <h1 className='text-white text-xl font-semibold'>{meteo.current.humidity} %</h1>
                <h1 className='text-white text-xl'>Humidite</h1>
              </div>
            </div>

            {/* Bloc vent */}
            <div className='flex items-center'>
              <img src="/meteo/vent.svg" alt="Vent" className="w-30 h-30" />
              <div className='flex flex-col gap-2'>
                <h1 className='text-white text-xl font-semibold'>{meteo.current.wind_kph} Km/h</h1>
                <h1 className='text-white text-xl'>Vent</h1>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}

export default App;
