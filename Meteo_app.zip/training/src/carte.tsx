const SOLEIL = [1000];
const PEU_NUAGEUX = [1003];
const NUAGEUX = [1006, 1009];
const BROUILLARD = [1030, 1135, 1147];
const PLUIE = [1063, 1150, 1153, 1168, 1171, 1180, 1183, 1186, 1189, 1192, 1195, 1198, 1201, 1240, 1243, 1246];
const NEIGE = [1066, 1114, 1117, 1210, 1213, 1216, 1219, 1222, 1225, 1255, 1258];
const GRESIL = [1069, 1072, 1204, 1207, 1237, 1249, 1252, 1261, 1264];
const ORAGE = [1087, 1273, 1276, 1279, 1282];

function choisirImage(code: number, isDay: number): string {
  if (SOLEIL.includes(code)) return isDay ? "soleil" : "lune";
  if (PEU_NUAGEUX.includes(code)) return isDay ? "peu-nuageux-jour" : "peu-nuageux-nuit";
  if (NUAGEUX.includes(code)) return "nuageux";
  if (BROUILLARD.includes(code)) return "brouillard";
  if (PLUIE.includes(code)) return "pluie";
  if (NEIGE.includes(code)) return "neige";
  if (GRESIL.includes(code)) return "gresil";
  if (ORAGE.includes(code)) return "orage";
  return "nuageux";
}

export default function IconeMeteo({ code, isDay, className = "w-48 h-48" }: { code: number; isDay: number; className?: string }) {
  const nom = choisirImage(code, isDay);
  return <img src={`/meteo/${nom}.svg`} alt={nom} className={className} />;
}