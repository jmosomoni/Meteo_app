import { useState } from "react";

type verite= {
    texte:string,
    term : boolean,
 

}
export function Po({texte, term}: verite) {
return (

<p className="p-2">

{term ?  "✅" : "⏳"} {texte}


</p>
);}




export function Compteur() {
const [valeur,setValeur] = useState(0)

return (
<div className="flex flex-col items-center">

<p> {valeur}</p>

<div className="flex gap-6 mt-3">
<button className=" font-bold text-base w-10 h-10 border-1 border-black rounded-md bg-blue-500 text-white" onClick={()=>setValeur(valeur +1)}>+1</button>
<button className=" font-bold text-base w-10 h-10 border-1 border-black rounded-md bg-red-500 text-white" onClick={()=>setValeur(valeur -1)}>-1</button>
</div>


</div>



)}

type propo ={

theme: string,
setTheme :(theme:string)=> void

}

export function Night({theme,setTheme}:propo) {
    return (
        <button onClick={()=>setTheme( theme==="light" ? "dark" : "light")}> click </button> )}





type code= {
name :string ,
setName: (name:string) => void, 
nombre :string,
setNombre: (nombre:string) => void ,

}

export function Appel({name,setName,nombre,setNombre}:code) {


return (

<form >

<label>Prenom</label>
<input type="text" value={name} onChange={(e)=>setName(e.target.value)}/>
<br></br>
<label>annee de naissance</label>
<input type="number" value={nombre}
onChange={(e)=> setNombre(e.target.value)}/>

</form>

)


}


type note={
champ:string
setChamp:(champ:string) => void
rep:string
setRep:(rep:string) => void
ecri:string[]
setEcri: (ecri:string[]) => void

}

export function Tache({ champ, setChamp, rep, setRep,ecri,setEcri }: note) {
  function ajouter(){
  setEcri([...ecri,champ])
  setChamp("")
   
  }

  function sup( index : number){
    setEcri(ecri.filter((tache,i) => i !== index))

  }
  
  
    return (
    <div>
      <form>
        <label>tache</label>
        <input type="text" value={champ} onChange={(e) => setChamp(e.target.value)} />
        <button type="button" onClick={() => {
     ajouter()}}>ajouter</button>
       
              
      
      </form>



<ul>
{ecri.map((tache,index)=>(

<li key={index}>{tache}    <button  onClick={()=>sup(index)} >supprimer</button> <input type="checkbox" defaultChecked className="checkbox checkbox-primary" />
 </li> 

))}

</ul>


    </div>
  )
}